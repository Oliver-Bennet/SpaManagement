from spaapp import app, db
from spaapp import admin
from spaapp import index

if __name__ == "__main__":
    app.run(debug=True)
